package com.nova.client.spearswap;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class SpearSwap {

    private static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("nova", "main"));

    private static final KeyBinding SPEAR_KEY = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.nova.spearswap", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, CATEGORY));

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (SPEAR_KEY.wasPressed()) {
                swapAndUse(client);
            }
        });
    }

    private static void swapAndUse(MinecraftClient client) {
        if (client.player == null || client.interactionManager == null) return;

        var player = client.player;
        var inv = player.getInventory();

        // Szukamy speara w hotbarze (0-8) i ekwipunku (9-35)
        int spearIndex = -1;
        for (int i = 0; i < 36; i++) {
            if (isSpear(inv.getStack(i))) {
                spearIndex = i;
                break;
            }
        }
        if (spearIndex == -1) return;

        if (spearIndex != 0) {
            // Zamiana lokalna, żeby użycie nie złapało starego itemu
            ItemStack first = inv.getStack(0).copy();
            ItemStack spear = inv.getStack(spearIndex).copy();
            inv.setStack(0, spear);
            inv.setStack(spearIndex, first);

            // Zamiana po stronie serwera (sloty ekwipunku gracza: hotbar = 36-44)
            int screenSlot = spearIndex < 9 ? spearIndex + 36 : spearIndex;
            client.interactionManager.clickSlot(
                    player.playerScreenHandler.syncId,
                    screenSlot,
                    0,
                    SlotActionType.SWAP,
                    player);
        }

        // Przełączenie na slot 1 i użycie
        inv.setSelectedSlot(0);
        client.interactionManager.interactItem(player, Hand.MAIN_HAND);
    }

    private static boolean isSpear(ItemStack stack) {
        if (stack.isEmpty()) return false;
        return Registries.ITEM.getId(stack.getItem()).getPath().contains("spear");
    }
}
