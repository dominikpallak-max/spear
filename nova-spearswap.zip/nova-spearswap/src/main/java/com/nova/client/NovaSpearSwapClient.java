package com.nova.client;

import com.nova.client.spearswap.SpearSwap;
import net.fabricmc.api.ClientModInitializer;

public class NovaSpearSwapClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        SpearSwap.init();
    }
}
